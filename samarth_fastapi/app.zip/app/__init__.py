# SAMARTH FastAPI Backend
